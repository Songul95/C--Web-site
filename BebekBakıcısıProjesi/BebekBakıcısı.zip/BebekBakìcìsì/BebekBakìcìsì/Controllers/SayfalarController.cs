﻿using Microsoft.AspNetCore.Mvc;

namespace BebekBakıcısı.Controllers
{
    public class SayfalarController : Controller
    {
        public IActionResult Hakkimizda()
        {
            return View();
        }
        public IActionResult Etkinlik()
        {
            return View();
        }
        public IActionResult Detaylar()
        {
            return View();
        }
        public IActionResult Galeri()
        {
            return View();
        }
        public IActionResult Referans()
        {
            return View();
        }
        public IActionResult Magaza()
        {
            return View();
        }
    }
}
