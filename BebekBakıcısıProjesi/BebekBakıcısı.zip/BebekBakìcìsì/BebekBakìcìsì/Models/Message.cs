﻿namespace EduKıds.Models
{
    public class Message
    {
        public int MesajId { get; set; }
        public string AdSoyad { get; set; }
        public string Mail { get; set; }
        public string Konu { get; set; }
        public string Telefon { get; set; }
        public string Mesaj { get; set; }
    }
}
